    // Andrew Roda, Clemens Strigl
// EECE 446
// PROGRAM 4
// 12/4/2022
#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX_LINE 256
#define MAX_PENDING 5
#define MAX_FILES 10
#define MAX_FILENAME_LEN 255

struct peer_entry {
  unsigned char id[4]; // ID of peer
  int sd;      // Socket descriptor for connection to peer
  char files[MAX_FILES][MAX_FILENAME_LEN]; // Files published by peer
  int file_c;                              // file count
  struct sockaddr_in address; // Contains IP address and port number
};

/*
 * Create, bind and passive open a socket on a local interface for the provided
 * service. Argument matches the second argument to getaddrinfo(3).
 *
 * Returns a passively opened socket or -1 on error. Caller is responsible for
 * calling accept and closing the socket.
 */
int sendMessage(char *msg, int size, int s);
int bind_and_listen(const char *service);
int join(int socket, struct peer_entry **peers, int *numPeers,
         struct sockaddr *remoteaddr, unsigned char *buf, int length);
int publish(struct peer_entry *peer, unsigned char *buf, int length);
int search(struct peer_entry **peers, int numPeers,unsigned char *buf, int length,
           int pindex);
int getAction(int s, unsigned char *buf, int length, struct peer_entry **peers,
              int *numPeers);
int alreadyAPeer(struct peer_entry **peers, int numPeers, int s);
/*
 * Return the maximum socket descriptor set in the argument.
 */
int find_max_fd(const fd_set *fs);

int main(int argc, char *argv[]) {
  const char *SERVER_PORT = argv[1];
  // all_sockets stores all active sockets
  // call_set is a temporary used for the select call
  fd_set all_sockets, call_set;
  FD_ZERO(&all_sockets);
  struct sockaddr remoteaddr;
  socklen_t addrlen;
  int newfd;

  struct peer_entry *peers[5];
  int numPeers = 0;

  // listen_socket is the fd on which the program can accept() new connections
  int listen_socket = bind_and_listen(SERVER_PORT);
  FD_SET(listen_socket, &all_sockets);

  // max_socket should always contain the socket fd with the largest value
  int max_socket = listen_socket;

  while (1) {
    call_set = all_sockets;
    int num_s = select(max_socket + 1, &call_set, NULL, NULL, NULL);
    if (num_s < 0) {
      perror("ERROR in select() call\n");
      return -1;
    }
    // Skip standard IN/OUT/ERROR -> start at 3
    for (int s = 3; s <= max_socket; ++s) {
      // Skip sockets that aren't ready
      if (!FD_ISSET(s, &call_set))
        continue;

      // A new connection is available
      if (s == listen_socket) {
        addrlen = sizeof(remoteaddr);
        newfd = accept(listen_socket, &remoteaddr, &addrlen);
        if (newfd == -1)
          perror("accept\n");
        else {
          FD_SET(newfd, &all_sockets);
          if (newfd > max_socket) {
            max_socket = newfd;
          }
        }
      } else {
        unsigned char finalBuf[1200];
        int length = 0;
        length = recv(s, finalBuf, 1200, 0);
        if (length == 0) {
          // connection closed
          close(s); // bye!
          FD_CLR(s, &all_sockets);
        } else if (length < 0) {
          perror("recv");
        }
        if (length > 0 && FD_ISSET(s, &all_sockets)) {
          int action = getAction(s, finalBuf, length, peers, &numPeers);
          switch (action) {
          case 0:
            join(s, peers, &numPeers, &remoteaddr, finalBuf, length);
            break;
          case 1:
            publish(peers[alreadyAPeer(peers, numPeers, s)], finalBuf, length);
            break;
          case 2:
            search(peers, numPeers, finalBuf, length,
                   alreadyAPeer(peers, numPeers, s));
            break;
          case -1:
            printf(
                "ERROR] (REGISTRY) PUBLISH recieved from unregistered peer\n");
            break;
          case -2:
            printf(
                "ERROR] (REGISTRY) SEARCH recieved from unregistered peer\n");
            break;
          default:
            perror("ERROR] (REGISTRY) action error");
          }
        }
      }
    }
  }
  return 0;
}

int getAction(int s, unsigned char *buf, int length, struct peer_entry **peers,
              int *numPeers) {
  if (length <= 0) {
    perror("invalid Command\n");
    return -1;
  }
  // -1 if not exist, else index of peer
  int p = alreadyAPeer(peers, *numPeers, s);
  int returnValue = (int)buf[0];

  if (p == -1) {
    returnValue = returnValue * -1;
  }
  return returnValue;
}

int join(int socket, struct peer_entry **peers, int *numPeers,
         struct sockaddr *remoteaddr, unsigned char *buf, int length) {
  if (*numPeers < 5) {
    if (length != 5) {
      perror("invalid JOIN Command\n");
      return -1;
    }
    peers[*numPeers] = (struct peer_entry *)malloc(sizeof(struct peer_entry));
    peers[*numPeers]->address = *(struct sockaddr_in *)remoteaddr;
    //unsigned char* tempid[4]; 
    //memcpy(tempid, buf+1, 4*sizeof(unsigned char)); 
    //unsigned char* x = tempid; 
    //peers[*numPeers]->id = *x; 
    peers[*numPeers]->id[0] = buf[1] ;
    peers[*numPeers]->id[1] = ((buf[2])) ;
    peers[*numPeers]->id[2] =((buf[3])) ;
    peers[*numPeers]->id[3] = (buf[4]);
    peers[*numPeers]->sd = socket;
    peers[*numPeers]->file_c = 0;
    printf("TEST] JOIN %u\n", ((buf[1] << 24)) | ((buf[2] << 16)) | ((buf[3] << 8)) | ((buf[4])));
    *numPeers = *numPeers + 1;
    return 1;
  } else {
    perror("MAX PEERS\n");
    return -1;
  }
  return 0;
}

int search(struct peer_entry **peers, int numPeers, unsigned char *buf, int length,
           int pindex) {

  int p, p_files;
  for (p = 0; p < numPeers; p++) {
    for (p_files = 0; p_files < peers[p]->file_c; p_files++) {
      if (!strcmp((const char*)&buf[1], peers[p]->files[p_files])) {
        // char *ip;
        uint32_t uint_ip = peers[p]->address.sin_addr.s_addr;
        uint16_t uint_port = peers[p]->address.sin_port;
        uint_port = ntohs(uint_port); //blackmagick f**kery, off by 2 without
        uint_port = htons(uint_port); 
        //printf("TEST] SEARCH %s %u %x:%d\n", &buf[1], peers[p]->id, uint_ip,
          //     ntohs(uint_port));
        char *msg = (char *)malloc(10);
        msg[3] = (peers[p]->id[3]);
        msg[2] = (peers[p]->id[2]);
        msg[1] = (peers[p]->id[1]);
        msg[0] = peers[p]->id[0];
        msg[7] = (uint_ip >> 24) & 0xFF; // hi kredo - i luv u 2
        msg[6] = (uint_ip >> 16) & 0xFF;
        msg[5] = (uint_ip >> 8) & 0xFF;
        msg[4] = uint_ip & 0xFF;
        msg[9] = (uint_port >> 8) & 0xFF;
        msg[8] = uint_port & 0xFF;
        printf("TEST] SEARCH %s %u %u.%u.%u.%u:%d\n", &buf[1], ((peers[p]->id[0] << 24)) | ((peers[p]->id[1] << 16)) | ((peers[p]->id[2] << 8)) | ((peers[p]->id[3])), msg[4],msg[5],msg[6],msg[7], ((ntohs(uint_port))));    
        // memcpy(&msg[4], ip, INET_ADDRSTRLEN);  (from when we tried not doing
        // the above) memcpy(&msg[8], &port, sizeof(port));
        sendMessage(msg, 10, peers[pindex]->sd);
        return 1;
      }
    }
  }
  char *msg = (char *)malloc(10);
  for (int i = 0; i < 10; i++) {
    msg[i] = 0;
  }
  sendMessage(msg, 10, peers[pindex]->sd);
  printf("TEST] SEARCH %s 0 0.0.0.0:0\n", &buf[1]);
  return 0;
}

// for peer, pass the peer entry * directly to function (peers[index])
int publish(struct peer_entry *peer, unsigned char *buf, int length) {
  uint32_t filecount = (buf[1] << 24) + (buf[2] << 16) + (buf[3] << 8) + buf[4];
  int findex = 0; // index for files in peer entry
  int pindex = 0; 
  int testcount = 0; 
  // loop through buffer, concact to peer->file when null is found from bindex,
  // update bindex to position after null
  for (int i = 5; i < length; i++) {
     if (buf[i] == '\0') {
      peer->files[findex][pindex] = '\0';
      findex++; 
      pindex = 0; 
      testcount++; 
      continue; 
    }
    peer->files[findex][pindex] = buf[i]; 
    pindex++; 
  }
  
  if(testcount != filecount){
    printf("count does not match specified #!\n");
  }
  peer->file_c = filecount;
  
  if (findex != filecount) {

    return -1; // if did not recieve amount of files specified by peer
  }
  printf("TEST] PUBLISH %x ", filecount);
  for (int i = 0; i < filecount; i++) {
    if(i == filecount-1){
      printf("%s", peer->files[i]); 
    }
    else{
    printf("%s ", peer->files[i]);
    }
  }
  printf("\n");
  return 0;
}

int find_max_fd(const fd_set *fs) {
  int ret = 0;
  for (int i = FD_SETSIZE; i >= 0 && ret == 0; --i) {
    if (FD_ISSET(i, fs)) {
      ret = i;
    }
  }
  return ret;
}

int bind_and_listen(const char *service) {
  struct addrinfo hints;
  struct addrinfo *rp, *result;
  int s;

  /* Build address data structure */
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;
  hints.ai_protocol = 0;

  /* Get local address info */
  if ((s = getaddrinfo(NULL, service, &hints, &result)) != 0) {
    fprintf(stderr, "stream-talk-server: getaddrinfo: %s\n", gai_strerror(s));
    exit(-1);
  }

  /* Iterate through the address list and try to perform passive open */
  for (rp = result; rp != NULL; rp = rp->ai_next) {
    if ((s = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol)) == -1) {
      continue;
    }

    if (!bind(s, rp->ai_addr, rp->ai_addrlen)) {
      break;
    }

    close(s);
  }
  if (rp == NULL) {
    perror("stream-talk-server: bind");
    exit(-1);
    return -1;
  }
  if (listen(s, MAX_PENDING) == -1) {
    perror("stream-talk-server: listen");
    close(s);
    return -1;
  }
  freeaddrinfo(result);
  return s;
}

int alreadyAPeer(struct peer_entry **peers, int numPeers, int s) {
  int p;
  for (p = 0; p < numPeers; p++) {
    if (s == peers[p]->sd)
      return p;
  }
  return -1;
}

int sendMessage(char *msg, int size, int s) {
  int total = 0;
  int bytsSent = 0;
  int bytsLeft = size;
  do {
    bytsSent = send(s, msg + total, bytsLeft, 0);
    if (bytsSent < 0) {
      free(msg);
      return 0; // if error
    }
    total = total + bytsSent;
    bytsLeft = bytsLeft - bytsSent;
  } while (total < size);
  free(msg);
  msg = NULL;
  return 1;
}
 